<!DOCTYPE html>
<head>
  <title>Task</title>
  <script src="<?php echo e(asset("js/app.js")); ?>"></script>
  <script src="https://js.pusher.com/7.0/pusher.min.js"></script>
  <link rel="stylesheet" href="<?php echo e(asset("css/app.css")); ?>">
</head>
<body>

<div class="container">
    
    <div class="row justify-content-center">
        
        <div class="col-md-8">
            <div class="card my-5">
                <a href="<?php echo e(route('home')); ?>" class="btn btn-primary">back to home page</a> 
                <div class="card-body">
                    <?php if(count($errors) > 0): ?>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="alert alert-danger">
                                <?php echo e($error); ?>

                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    <form action="<?php echo e(route('tasks.sendMessage')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="message">task : </label>
                            <input type="text" name="message" id="message" class="form-control">
                        </div>

                        <button type="submit" class="btn btn-primary">send</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

</body><?php /**PATH /home/masoud/public_html/laravel_test/resources/views/form.blade.php ENDPATH**/ ?>