<!DOCTYPE html>

<head>
    <title>Todo List</title>
    
    
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"
        integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
    <script src="https://js.pusher.com/7.0/pusher.min.js"></script>
    <script>
        // Enable pusher logging - don't include this in production
    Pusher.logToConsole = true;

    var pusher = new Pusher('308cb53dc8ce56b20c50', {
      cluster: 'eu',
      forceTLS: true
    });

    var channel = pusher.subscribe('message-channel');
    channel.bind('message-event', function(data) {
        let messageSection = $("#message");
        console.log(data)
        messageSection.append(`
        <div class='alert alert-primary'>${data.message}</div>
        `);
    });
    </script>
    <link rel="stylesheet" href="<?php echo e(asset("css/app.css")); ?>">
</head>

<body>

    <div class="container">
        
        <h1>Todo List</h1><a href="<?php echo e(route('formTask')); ?>" class="btn btn-success">task+</a> 
        <hr>
        <div id="message"></div>
        <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <div class='alert alert-primary'><?php echo e($task->message); ?>

             <a href="<?php echo e(route("tasks.edit" , $task->id)); ?>" style="color:blue">ویرایش</a>
            <form action="<?php echo e(route("tasks.delete" , $task->id)); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo e(method_field("DELETE")); ?>

                <input type="submit" style="color:red" value="*">
            </form>
         </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

</body><?php /**PATH /home/masoud/public_html/laravel_test/resources/views/message.blade.php ENDPATH**/ ?>