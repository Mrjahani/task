<?php

namespace Tests\Feature;

use App\Models\Task;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Foundation\Testing\WithFaker;
use Illuminate\Http\Response;
use Tests\TestCase;

class MessageControllerTest extends TestCase
{
    /**
     * A basic feature test example.
     *
     * @return void
     */
    public function test_home_page()
    {
        $response = $this->get(route("home"));

        $response->assertStatus(200);
    }

    public function test_show_this_task_manager_form()
    {
        $response = $this->get(route("formTask"));
        $response->assertStatus(Response::HTTP_OK);
    }

    public function test_send_task()
    {
        $task = Task::factory(1)->create();
        $response = $this->postJson(route("sendMessage",[
            'message' => $task
        ]));
        $response->assertStatus(Response::HTTP_ACCEPTED);
    }
}
