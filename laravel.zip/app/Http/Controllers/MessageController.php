<?php

namespace App\Http\Controllers;

use App\Models\Task;
use App\Events\SendMessage;
use Illuminate\Http\Request;
use App\Http\Requests\TaskRequest;
use Illuminate\Support\Facades\Cookie;

class MessageController extends Controller
{
    public function store(TaskRequest $request)
    {
        $message = $request->message;
        event(new SendMessage($message));
        $task = Task::create([
            'message' => $message,
        ]);
        return back();
    }
}
