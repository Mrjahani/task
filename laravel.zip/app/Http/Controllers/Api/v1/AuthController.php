<?php

namespace App\Http\Controllers\Api\v1;

use App\Http\Controllers\Controller;
use App\Http\Requests\AuthRequest;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Validator;

class AuthController extends Controller
{
    /**
     * @method POST
     * @param \App\Http\Requests\AuthRequest $request
     *
     * @return \Illuminate\Http\JsonResponse
     * @throws ValidationException
     */
    public function register(AuthRequest $request)
    {
        return response()->json(["message" => "user created"], Response::HTTP_CREATED);
    }
}
